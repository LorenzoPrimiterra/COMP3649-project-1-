"""
parser.py
=========
Reads an input file and turns each line into structured Python objects
that the rest of the program can work with.

Role in the Pipeline
--------------------
First stage after main.py opens the file:

    main.py          ← opens the file and passes it to the parser
          ↓
    parser.py        ← reads and validates each line, builds the instruction list
          ↓
    intermediate.py  ← receives the Operation list and live-out variables

Responsibilities
----------------
- Read and validate each instruction line from the input file
- Break each line into tokens (handles spacing like a=b+c and a = b + c)
- Check that destinations are valid variables and operands are valid
- Parse the final 'live:' line into a list of variable names
- Raise ParseError on any invalid input
- Return a populated IntermediateCode object

Out of Scope
------------
- Opening or closing files (main.py)
- Performing liveness analysis (liveness.py)
- Building interference graphs or assigning registers (interference.py)
- Generating assembly instructions (target.py)

Key Abstractions
----------------
readIntermediateCode(f)
    Top-level function. Reads the file and returns a complete
    IntermediateCode object.

read3AddrInstruction(line)
    Parses a single instruction line into an Operation object.

tokenize_line(line)
    Breaks a raw line of text into a clean list of tokens.

parse_live_line(line, operations)
    Parses the final 'live:' line and validates the variable names.

Dependencies
------------
- errors.py      : ParseError raised on any malformed input
- intermediate.py : Operation and IntermediateCode objects are constructed here

Usage Example
-------------
NA

Notes
-----
NA

"""

from typing import TextIO, List

import string
import re
from errors import ParseError
from intermediate import Operation, IntermediateCode


def readIntermediateCode(f: TextIO) -> IntermediateCode:
    """
    Parse an entire intermediate-code input file.

    File structure:
      - Zero or more three-address instruction lines
      - One final non-empty line of the form: 'live: ...'

    Responsibilities:
    - Read all non-empty lines
    - Parse each instruction line using read3AddrInstruction
    - Parse the final live-out line using parse_live_lineA

    - Populate and return an IntermediateCode object

    Returns:
      An IntermediateCode object containing:
        - the list of parsed Operation objects
        - the list of live-out variables

    Raises:
      ParseError if:
        - the file is empty
        - the final line is not a valid 'live:' line
        - any instruction line is malformed

    """


    operations = []
    prev = None

    for line in f:
        if prev is not None:
            op = read3AddrInstruction(prev)
            if op is not None:
              operations.append(op)
        prev = line

    if prev is None:
        raise ParseError("Empty file")

    live_out = parse_live_line(prev, operations)

    return IntermediateCode(operations, live_out)  



def tokenize_line(line: str) -> List[str]:
    """
    Break a single line of intermediate code into tokens.

    Requirements:
    - Operators (+, -, *, /) and '=' must appear as separate tokens
    - Tokenization must be whitespace-insensitive
    - Works for lines with or without spaces (e.g., 'a=a+1')

    Examples:
      "a = a + 1" -> ["a", "=", "a", "+", "1"]
      "x = -y"    -> ["x", "=", "-", "y"]
      "t1 = 10"   -> ["t1", "=", "10"]

    Raises:
      ParseError if tokenization fails or results in an invalid token sequence.
    """

    # Remove surrounding whitespace
    line = line.strip()
    if not line:
        return[] 

    """Removes delimiters/spaces and if they are next to eachother
    only splits over whitespace/semi-colon/commas
    hence breaks when there is a delimeter between them like "a=a+1" or "t1=t2*3"
    because the entire expression becomes one token ("a=a+1") and the parser
    never sees "=" or "+" as separate tokens.
    Using re.findall with a token pattern fixes this by extracting identifiers,
    integers (including -10), and single-char operators (= + - * /) as distinct tokens."""

    # delimiters = r"[,\s;\n]+"
    # tokens = re.split(delimiters, line.strip()) 

    """ New (extract tokens directly, including operators as tokens)"""
    token_pattern = r"-?\d+|[A-Za-z][A-Za-z0-9_]*|[=+\-*/]"
    tokens = re.findall(token_pattern, line)

    # Validate tokens
    valid_chars = set(string.ascii_letters + string.digits + "+-/*=_")
    valid_tokens = []
    for t in tokens:
      for ch in t:
        if ch not in valid_chars:
          raise ParseError(f"Invalid character '{ch}' in token: {t}")
        
    # output valid tokens to a list
         
      valid_tokens.append(t)
   
    return valid_tokens

        
""" 
Below defines the main read3AddrInstruction function and all its complimentary helper functions consisting of:
(1) is_valid_variable
(2) is_valid_operand
(3) validate_length_3
(4) validate_length_4
(5) validate_length_5 
(6) dest_equals_source_check

 """


def is_valid_variable(var: str) -> bool:
    """
    Project variable rule:
      - one lowercase letter excluding 't'  (a..z but not t)
      - OR 't' followed by one or more digits (t1, t2, ...)
    """
    return bool(re.fullmatch(r"(?:[a-su-z]|t\d+)", var))



def is_valid_operand(s: str) -> bool:
    """
    Checkk if string is a valid operand (variable or integer literal)..
    """
    is_var = re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", s)
    is_int = re.fullmatch(r"-?\d+", s)
    
    if is_var:
        return True
    if is_int:
        return True
    return False



def validate_length_3(tokens):
    """
    Validate and handle dst = src format.
    """
    src = tokens[2]

    if not is_valid_operand(src):
        raise ParseError("Invalid source within [dst = src] format.")
    


def validate_length_4(tokens):
    """
    Validate and handle dst = -src format.
    """
    negative = tokens[2]
    src = tokens[3]

    if negative != "-":
        raise ParseError("Expected unary '-' in [dst = -src] format.")

    if not is_valid_operand(src):
        raise ParseError("Invalid source within [dst = -src] format.")
    


def validate_length_5(tokens):
    """
    Validate and handle dst = src1 op src2 format.
    """
    src1 = tokens[2]
    op   = tokens[3]
    src2 = tokens[4]

    # Validate operator
    if op not in {"+", "-", "*", "/"}:
        raise ParseError("Invalid operator in [dst = src1 op src2] format.")

    # Validate src11
    if not is_valid_operand(src1):
        raise ParseError("Invalid first operand in [dst = src1 op src2] format.")

    # Validate src2
    if not is_valid_operand(src2):
        raise ParseError("Invalid second operand in [dst = src1 op src2] format.")
    


def read3AddrInstruction(line: str) -> Operation:
    """
    Parse a single three-address instruction.

    Supported instruction forms:
      dst = src
      dst = -src
      dst = src1 op src2

    Requirements:
    - dst must be a valid variable
    - src operands must be valid variables or integer literals
    - op must be one of +, -, *, /

    Returns:
      An Operation (three-address instruction) object.

    Raises:
      ParseError if the instruction format is invalid.
    """
    # tokenzied line with valid op check already done
    tokens = tokenize_line(line)
  
    # skip blank lines
    if not tokens:
        return None

    length = len(tokens)

    if length not in (3, 4, 5):
        raise ParseError("Invalid instruction size. Expected three-address instruction.")

    # Validate destination variable
    dest = tokens[0]
    if not is_valid_variable(dest):
        raise ParseError("Invalid destination type.")

    dest_equals_source_check(length, tokens)

    # Return the appropriate Operation based on instruction type
    if length == 3:
        # dst = src
        return Operation(dest, tokens[2])
    elif length == 4:
        # dst = -src (unary minus)
        return Operation(dest, tokens[3], unary_neg=True)
    elif length == 5:
        # dst = src1 op src2
        return Operation(dest, tokens[2], tokens[3], tokens[4])
    


def dest_equals_source_check(length: int, tokens: List[str]) -> None:
    """
    This helper function (given the len(token) and tokens = tokenize_line(line)) checks
    which condition needs to be looked at of the three potential options.
    """
    # dst = src
    if length == 3:
        validate_length_3(tokens)
    # checks if dst = -src
    elif length == 4:
        validate_length_4(tokens)
    # dst = src1 op src2
    elif length == 5:
        validate_length_5(tokens)



def parse_live_line(line: str, operations: List[Operation]) -> List[str]:
    
    """
    Parse the final 'live:' line of the input file.

    Input format:
      live: v1, v2, v3
      Operations: valid operations determined via read3AddrInstructions

    Requirements:
    - Must start with 'live:'
    - Variables must be comma-separated
    - Variables must follow the project naming rules
    - Variables listed must have appeared earlier in the code

    Returns:
      A list of variable names live on exit.

    Raises:
      ParseError if the line is invalid.
    """

    line = line.strip()
    
   
    # Check if the first element is 'live:'
    if not line.startswith("live:"):
        raise ParseError("Final line must start with 'live:'")

    # Removes live section
    rest_of_line = line[5:].strip()
    
    # Handle empty live set (spec allows 0 variables after 'live:')
    if not rest_of_line:
        return []

    # splits the rest of the string on comma's to get each variable
    live_vars = rest_of_line.split(',')
    
    
     # Clean up whitespace and validate each variable
    for i in range(len(live_vars)):
        live_vars[i] = live_vars[i].strip()
        # Check if valid variable name 
        if not is_valid_variable(live_vars[i]):
            raise ParseError(f"Invalid variable name: '{live_vars[i]}'")
    
    # Check that each live variable appeared in the code
    for var in live_vars:
        found = False
        
        for op in operations:
            if var == op.destination or var == op.operand1 or var == op.operand2:
                found = True
                break
        
        if not found:
            raise ParseError(f"Variable '{var}' not found in code")
    
    return live_vars



   